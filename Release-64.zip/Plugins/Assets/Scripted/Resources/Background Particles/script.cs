using System;
using System.Collections.Generic;
using OpenTK;
using OpenTK.Graphics;
using ScriptedEngine;
using ZenithEngine;

class Particle
{
    public Vector2d pos;
    public Vector2d vel;
    public double rotation;
    public double rotationVel;
    public Color4 color;
    public double size;
    public double life;

    public Particle(Vector2d pos, Vector2d vel, double rotation, double rotationVel, Color4 color, double size, double life)
    {
        this.pos = pos;
        this.vel = vel;
        this.rotation = rotation;
        this.rotationVel = rotationVel;
        this.color = color;
        this.size = size;
        this.life = life;
    }

    public void Physics()
    {
        double gravity = 0.01;

        vel.Y -= gravity;

        pos += vel;
        rotation -= rotationVel;

        // If hit ground
        if (pos.Y < 0)
        {
            // Bounce
            pos.Y *= -1;
            vel.Y *= -1;
            vel.Y -= 0.003;
            if (vel.Y < 0)
            {
                vel.Y = 0;
                pos.Y = 0;
            }

            // Friction
            double surfaceVel = rotationVel * size * 0.7;
            double diff = vel.X - surfaceVel;
            vel.X -= diff * 0.2;
            rotationVel += diff * 0.2 / size / 0.7;
            vel.X *= 0.9;
        }
    }
}

public class Script
{
    public string Description = "Particle Script for background, with edited gravity and velocity!";
    public string Preview = "preview.png";

    // A linked list of particles. Linked lists allow the renderer to add and remove particles much quicker than normal lists.
    LinkedList<Particle> particles = new LinkedList<Particle>();

    int maxParticles = 1500;

    Random r = new Random();

    public void Load()
    {
        // This script doesn't require any loading    
    }

    public void Render(IEnumerable<Note> notes, RenderOptions options)
    {
        double keyboardHeight = 0.0;

        // The variables below are used to convert notes from tick positions to screen position
        // It's calculated here rather than each time a note is drawn for optimization
        double notePosFactor = 1 / options.noteScreenTime * (1 - keyboardHeight);
        double renderCutoff = options.midiTime + options.noteScreenTime;

        // The keyboard layout, each key's and note's left and right edges as well as some other metadata
        var layout = Util.GetKeyboardLayout(options.firstKey, options.lastKey, new KeyboardOptions());

        // The colors of each key. 512 instead of 256 because gradients.
        var keyColors = new Color4[514];
        var keyNotes = new int[257];

        // Loop over each note
        foreach (var note in Util.BlackNotesAbove(notes))
        {
            // If a note is above or below the view, skip it.
            if (note.hasEnded && note.end < options.midiTime || note.start > renderCutoff) continue;

            // Get the coordinates of the note's edges
            double top = 1 - (renderCutoff - note.end) * notePosFactor;
            double bottom = 1 - (renderCutoff - note.start) * notePosFactor;
            double left = layout.keys[note.key].left;
            double right = layout.keys[note.key].right;
            // If a note hasn't ended, set it's top coordinate to the top of the screen
            if (!note.hasEnded) top = 1;

            // Check if the note is touching the keyboard
            if (note.start < options.midiTime)
            {
                // If it is, blend the current key's color with the note color
                // Blending is useful if the notes are semi-transparent
                keyColors[note.key * 2] = Util.BlendColors(keyColors[note.key * 2], note.color.left);
                keyColors[note.key * 2 + 1] = Util.BlendColors(keyColors[note.key * 2 + 1], note.color.right);

                // Add to key's hit note count for this frame
                keyNotes[note.key]++;
            }
        }

        // If the start/end keys are black, render an extra white key next to them
        int firstKey = options.firstKey;
        int lastKey = options.lastKey;
        if (layout.blackKey[firstKey]) firstKey--;
        if (layout.blackKey[lastKey - 1]) lastKey++;

        // Loop over all visible keys
        for (int i = firstKey; i < lastKey; i++)
        {
            // Chance of a particle being spawned each frame on this key is:
            // 10% * sqrt(key's hit note count)
            var chance = Math.Sqrt(keyNotes[i]) * 0.1;
            // r.NextDouble() picks a random number between 0 and 1
            if (r.NextDouble() < chance)
            {
                // Scale of random velocity. Change this if you want particles to fly faster/slower.
                double velScale = 0.001;

                var pos = new Vector2d(layout.keys[i].left + (layout.keys[i].right - layout.keys[i].left) * r.NextDouble(), 0);
                var vel = new Vector2d((r.NextDouble() * 2 - 1) * r.NextDouble() * velScale * 0.3, r.NextDouble() * velScale);
                var rot = r.NextDouble() * Math.PI;
                var rotVel = r.NextDouble() * Math.PI / 5;
                var size = r.NextDouble() * 0.005 + 0.001;
                // Between 6 and 9 seconds (counted in frames at 60fps)
                var life = (int)(r.NextDouble() * 60 * 3) + 60 * 6;
                particles.AddLast(new Particle(pos, vel, rot, rotVel, keyColors[i * 2], size, life));
                if (particles.Count > maxParticles) particles.RemoveFirst();
            }
        }

        // Loop over all elements in the linked list
        var node = particles.First;
        while (node != null)
        {
            var p = node.Value;
            p.Physics();
            p.life -= 1;

            // Calculate parameters and render the particle shape
            double cos = Math.Cos(p.rotation);
            double sin = Math.Sin(p.rotation);
            var pos = p.pos + new Vector2d(0, keyboardHeight + p.size * 0.7);
            var aspect = options.renderAspectRatio;
            var opacity = Math.Min(1, p.life / 60 / 3);
            var color = p.color;
            color.A *= (float)opacity;
            IO.RenderShape(
                pos + new Vector2d(cos, sin * aspect) * p.size,
                pos + new Vector2d(-sin, cos * aspect) * p.size,
                pos - new Vector2d(cos, sin * aspect) * p.size,
                pos - new Vector2d(-sin, cos * aspect) * p.size,
                color
            );

            // If particle dying, remove it from the list
            var _node = node;
            node = node.Next;
            if (p.life < 0) particles.Remove(_node);
        }
    }

    // Optional function, called when renderer is starting
    public void RenderInit(RenderOptions options)
    {

    }

    // Optional function, called when renderer is closing
    public void RenderDispose()
    {
        particles.Clear();
    }
}