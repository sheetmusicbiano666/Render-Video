using System;
using System.Collections.Generic;
using OpenTK;
using OpenTK.Graphics;
using ScriptedEngine;
using ZenithEngine;

public class Script
{
  public string Description = "A joke script to make fun of the bugs in BPFA.\nMade by Kaydax, a BPFA developer\n\"I blame khang\"";
  public bool ManualNoteDelete { get { return !optimizedModeCheck.Checked; } }
  Random r = new Random();

  public UISetting[] SettingsUI;
  UICheckbox optimizedModeCheck = new UICheckbox("Optimized Mode", false);
  public string Preview = "preview.png";

  public void Load()
  {
    SettingsUI = new UISetting[]
    {
      optimizedModeCheck
    };
  }

  public void Render(IEnumerable<Note> notes, RenderOptions options)
  {
    double keyboardHeight = 0.15;

    double borderWidth = 1;

    double notePosFactor = 1 / options.noteScreenTime * (1 - keyboardHeight);
    double renderCutoff = options.midiTime + options.noteScreenTime;

    bool optimizedMode = optimizedModeCheck.Checked;

    var layout = Util.GetKeyboardLayout(options.firstKey, options.lastKey, new KeyboardOptions()
    {
      blackKey2setOffset = 0.4,
      blackKey3setOffset = 0.4,
      blackKeyScale = 0.64f
    });

    var keyColors = new Color4[514];
    var keyPressed = new bool[257];

    double paddingx = 0.001 * borderWidth;
    double paddingy = paddingx * options.renderWidth / options.renderHeight;

    foreach (var note in Util.BlackNotesAbove(notes))
    {
      if (optimizedMode)
      {
        if (note.hasEnded && note.end < options.midiTime || note.start > renderCutoff) continue;

        if (note.start < options.midiTime) continue;
      }
      else
      {
        if (note.hasEnded && note.end < options.midiTime || r.NextDouble() < 0.001) note.delete = true;
        if (note.hasEnded && note.end < (options.midiTime + options.noteScreenTime / 5) || note.start > renderCutoff) continue;
      }

      double top = 1 - (renderCutoff - note.end) * notePosFactor;
      double bottom = 1 - (renderCutoff - note.start) * notePosFactor;
      double left = layout.keys[note.key].left;
      double right = layout.keys[note.key].right;
      if (!note.hasEnded) top = 1.5;

      if (note.start < options.midiTime)
      {
        keyPressed[note.key] = true;
        keyColors[note.key * 2] = Util.BlendColors(keyColors[note.key * 2], note.color.left);
        keyColors[note.key * 2 + 1] = Util.BlendColors(keyColors[note.key * 2 + 1], note.color.right);
      }

      var coll = note.color.left;
      var colr = note.color.right;
      coll.R *= 0.2f;
      coll.G *= 0.2f;
      coll.B *= 0.2f;
      colr.R *= 0.2f;
      colr.G *= 0.2f;
      colr.B *= 0.2f;

      IO.RenderQuad(left, top, right, bottom, colr, coll, coll, colr);

      if (top - bottom > paddingy * 2)
      {
        top -= paddingy;
        bottom += paddingy;
        right -= paddingx;
        left += paddingx;

        coll = note.color.left;
        colr = note.color.right;
        coll.R *= 0.5f;
        coll.G *= 0.5f;
        coll.B *= 0.5f;

        IO.RenderQuad(left, top, right, bottom, colr, coll, coll, colr);
      }

    }

    int firstKey = options.firstKey;
    int lastKey = options.lastKey;
    if (layout.blackKey[firstKey]) firstKey--;
    if (layout.blackKey[lastKey - 1]) lastKey++;

    double pianoHeight = 0.151;

    pianoHeight = pianoHeight / (options.lastKey - options.firstKey) * 128;
    pianoHeight = pianoHeight / (1920.0 / 1080.0) * options.renderAspectRatio;

    double topRedStart = pianoHeight * .99;
    double topRedEnd = pianoHeight * .94;
    double topBarEnd = pianoHeight * .927;

    double wEndUpT = pianoHeight * 0.03 + pianoHeight * 0.020;
    double wEndUpB = pianoHeight * 0.03 + pianoHeight * 0.005;
    double wEndDownT = pianoHeight * 0.01;
    double bKeyEnd = pianoHeight * .345;
    double bKeyDownT = topBarEnd + pianoHeight * 0.015;
    double bKeyDownB = bKeyEnd + pianoHeight * 0.015;
    double bKeyUpT = topBarEnd + pianoHeight * 0.045;
    double bKeyUpB = bKeyEnd + pianoHeight * 0.045;

    double bKeyUSplitLT = pianoHeight * 0.78;
    double bKeyUSplitRT = pianoHeight * 0.71;
    double bKeyUSplitLB = pianoHeight * 0.65;
    double bKeyUSplitRB = pianoHeight * 0.58;

    double sepwdth = Math.Round(layout.whiteKeyWidth * options.renderWidth / 20);
    if (sepwdth == 0) sepwdth = 1;

    Color4 col1;
    Color4 col2;
    Color4 col3;
    Color4 col4;

    col1 = new Color4(.086f, .086f, .086f, 1);
    col2 = new Color4(.0196f, .0196f, .0196f, 1);
    IO.RenderQuad(0, pianoHeight, 1, topRedStart, col2, col2, col1, col1);

    //0000e6
    float topBarR = 0x00;
    float topBarG = 0x00;
    float topBarB = 0xe6;

    col1 = new Color4(topBarR, topBarG, topBarB, 1);
    col2 = new Color4(topBarR / 2, topBarG / 2, topBarB / 2, 1);
    IO.RenderQuad(0, topRedStart, 1, topRedEnd, col2, col2, col1, col1);

    IO.RenderQuad(0, topRedEnd, 1, topBarEnd, new Color4(.239f, .239f, .239f, 1));

    for (int i = firstKey; i < lastKey; i++)
    {
      if (!layout.blackKey[i])
      {
        double left = layout.keys[i].left;
        double right = layout.keys[i].right;

        Color4 leftCol = Util.BlendColors(new Color4(255, 255, 255, 255), keyColors[i * 2]);
        Color4 rightCol = Util.BlendColors(new Color4(255, 255, 255, 255), keyColors[i * 2 + 1]);

        if (keyPressed[i])
        {
          col1 = rightCol;
          col1.R *= 0.5f;
          col1.G *= 0.5f;
          col1.B *= 0.5f;
          IO.RenderQuad(left, topBarEnd, right, wEndDownT, col1, col1, leftCol, leftCol);

          col1 = leftCol;
          col1.R *= 0.6f;
          col1.G *= 0.6f;
          col1.B *= 0.6f;
          IO.RenderQuad(left, wEndDownT, right, 0, col1, col1, col1, col1);
        }
        else
        {
          col1 = rightCol;
          col1.R *= 0.8f;
          col1.G *= 0.8f;
          col1.B *= 0.8f;
          IO.RenderQuad(left, topBarEnd, right, wEndUpT, col1, col1, rightCol, rightCol);

          col1 = leftCol;
          col1.R *= .529f;
          col1.G *= .529f;
          col1.B *= .529f;
          col2 = leftCol;
          col2.R *= .329f;
          col2.G *= .329f;
          col2.B *= .329f;
          IO.RenderQuad(left, wEndUpT, right, wEndUpB, col2, col2, col1, col1);

          col1 = leftCol;
          col1.R *= .615f;
          col1.G *= .615f;
          col1.B *= .615f;
          col2 = leftCol;
          col2.R *= .729f;
          col2.G *= .729f;
          col2.B *= .729f;
          IO.RenderQuad(left, wEndUpB, right, 0, col2, col2, col1, col1);

        }

        var scleft = Math.Floor(left * options.renderWidth - sepwdth / 2);
        var scright = Math.Floor(left * options.renderWidth + sepwdth / 2);
        if (scleft == scright) scright++;
        scleft /= options.renderWidth;
        scright /= options.renderWidth;


        col1 = new Color4(.0431f, .0431f, .0431f, 1);
        col2 = new Color4(.556f, .556f, .556f, 1);
        IO.RenderQuad(scleft, topBarEnd, scright, 0, col1, col2, col2, col1);
      }
    }

    var mright = layout.keys[60].right;
    var mleft = layout.keys[60].left;
    var width = layout.whiteKeyWidth;
    var mbottom = wEndUpT + (mright - mleft) / 4;
    if (keyPressed[60])
    {
      mbottom = wEndDownT + (mright - mleft) / 4;
    }
    var mtop = mbottom + (mright - mleft) / 2 * options.renderAspectRatio;
    var colBox = keyColors[60 * 2];
    colBox.R *= 0.8f;
    colBox.G *= 0.8f;
    colBox.B *= 0.8f;
    if (!keyPressed[60])
    {
      colBox = new Color4(0.8f, 0.8f, 0.8f, 1f);
    }

    mright -= width / 4;
    mleft += width / 4;

    IO.RenderQuad(mleft, mtop, mright, mbottom, colBox);

    for (int i = firstKey; i < lastKey; i++)
    {
      if (layout.blackKey[i])
      {
        double left = layout.keys[i].left;
        double right = layout.keys[i].right;

        double ileft = left + layout.blackKeyWidth / 8;
        double iright = right - layout.blackKeyWidth / 8;

        Color4 leftCol = Util.BlendColors(new Color4(0, 0, 0, 255), keyColors[i * 2]);
        Color4 rightCol = Util.BlendColors(new Color4(0, 0, 0, 255), keyColors[i * 2 + 1]);

        Color4 middleCol = new Color4(
            (leftCol.R + rightCol.R) / 2,
            (leftCol.G + rightCol.G) / 2,
            (leftCol.B + rightCol.B) / 2,
            (leftCol.A + rightCol.A) / 2
            );

        if (!keyPressed[i])
        {
          col1 = rightCol;
          col1.R += 0.25f;
          col1.G += 0.25f;
          col1.B += 0.25f;
          col2 = leftCol;
          col2.R += 0.15f;
          col2.G += 0.15f;
          col2.B += 0.15f;
          col3 = leftCol;
          col3.R += 0.0f;
          col3.G += 0.0f;
          col3.B += 0.0f;
          col4 = leftCol;
          col4.R += 0.3f;
          col4.G += 0.3f;
          col4.B += 0.3f;

          IO.RenderShape(
              new Vector2d(ileft, bKeyUSplitLT),
              new Vector2d(iright, bKeyUSplitRT),
              new Vector2d(iright, bKeyUpT),
              new Vector2d(ileft, bKeyUpT),
              col1, col1, col2, col2);

          IO.RenderShape(
              new Vector2d(ileft, bKeyUSplitLB),
              new Vector2d(iright, bKeyUSplitRB),
              new Vector2d(iright, bKeyUSplitRT),
              new Vector2d(ileft, bKeyUSplitLT),
              col3, col3, col1, col1);

          IO.RenderShape(
              new Vector2d(ileft, bKeyUpB),
              new Vector2d(iright, bKeyUpB),
              new Vector2d(iright, bKeyUSplitRB),
              new Vector2d(ileft, bKeyUSplitLB),
              col3, col3, col3, col3);

          IO.RenderShape(
              new Vector2d(left, bKeyEnd),
              new Vector2d(ileft, bKeyUpB),
              new Vector2d(ileft, bKeyUpT),
              new Vector2d(left, topBarEnd),
              col3, col4, col4, col3);

          IO.RenderShape(
              new Vector2d(right, bKeyEnd),
              new Vector2d(iright, bKeyUpB),
              new Vector2d(iright, bKeyUpT),
              new Vector2d(right, topBarEnd),
              col3, col4, col4, col3);

          IO.RenderShape(
              new Vector2d(left, bKeyEnd),
              new Vector2d(right, bKeyEnd),
              new Vector2d(iright, bKeyUpB),
              new Vector2d(ileft, bKeyUpB),
              col3, col3, col4, col4);
        }
        else
        {
          col1 = middleCol;
          col1.R *= 0.85f;
          col1.G *= 0.85f;
          col1.B *= 0.85f;
          col2 = rightCol;
          col2.R *= 0.85f;
          col2.G *= 0.85f;
          col2.B *= 0.85f;
          col3 = middleCol;
          col3.R *= 0.7f;
          col3.G *= 0.7f;
          col3.B *= 0.7f;
          col4 = leftCol;
          col4.R *= 0.7f;
          col4.G *= 0.7f;
          col4.B *= 0.7f;

          IO.RenderShape(
              new Vector2d(ileft, bKeyUSplitLT),
              new Vector2d(iright, bKeyUSplitRT),
              new Vector2d(iright, bKeyDownT),
              new Vector2d(ileft, bKeyDownT),
              col1, col1, col2, col2);

          IO.RenderShape(
              new Vector2d(ileft, bKeyUSplitLB),
              new Vector2d(iright, bKeyUSplitRB),
              new Vector2d(iright, bKeyUSplitRT),
              new Vector2d(ileft, bKeyUSplitLT),
              col3, col3, col1, col1);

          IO.RenderShape(
              new Vector2d(ileft, bKeyDownB),
              new Vector2d(iright, bKeyDownB),
              new Vector2d(iright, bKeyUSplitRB),
              new Vector2d(ileft, bKeyUSplitLB),
              col4, col4, col3, col3);


          col1 = leftCol;
          col1.R *= 0.7f;
          col1.G *= 0.7f;
          col1.B *= 0.7f;
          col2 = rightCol;
          col2.R *= 0.7f;
          col2.G *= 0.7f;
          col2.B *= 0.7f;

          IO.RenderShape(
              new Vector2d(left, bKeyEnd),
              new Vector2d(ileft, bKeyDownB),
              new Vector2d(ileft, bKeyDownT),
              new Vector2d(left, topBarEnd),
              col1, leftCol, rightCol, col2);

          IO.RenderShape(
              new Vector2d(right, bKeyEnd),
              new Vector2d(iright, bKeyDownB),
              new Vector2d(iright, bKeyDownT),
              new Vector2d(right, topBarEnd),
              col1, leftCol, rightCol, col2);

          IO.RenderShape(
              new Vector2d(left, bKeyEnd),
              new Vector2d(right, bKeyEnd),
              new Vector2d(iright, bKeyDownB),
              new Vector2d(ileft, bKeyDownB),
              col1, col1, leftCol, leftCol);
        }
      }
    }
  }
}